/*header files*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct person 	/*creating struct of person */
{
char name[25];
char surname[25];
char musical_Work[25];
int age;
struct person *next;
} *top;
/*fuction prototypes*/
void menu();
void addNode(char name[], char surname [], char creation [], int age);
void print_stack(struct person *node);
void deleteNode();
void sort(struct person **top,char x);
void partition(struct person *head,struct person **front ,struct person **back);
struct person* merge(struct person *a,struct person *b,char x);

int main()
{
	char name[25],surname[25],creation[25];
	int choice,age;
	while (choice!=5)/*exit condition from menu*/
	{
		printf("\n");
		menu();		/*calling menu function*/
		printf("enter your choice:");
		scanf("%d",&choice); /*user enters his choice according to the options available in menu*/
		printf("------------------\n");	
		switch(choice)	/*according to the choice we go to a specific task*/
		{
			case 1:
				printf("Name:");
				scanf(" %[^\n]s",name);	/*taking name from user excluding white spaces*/
				printf("Surname:");
				scanf(" %[^\n]s",surname); /*taking surname from user excluding white spaces*/
				printf("Creation:");
				scanf(" %[^\n]s",creation);	/*taking musical creation work from user excluding white spaces*/
				printf("Age:");
				scanf("%d",&age); /*taking age from the user*/
				addNode(name,surname,creation,age);	/*function call to addNode to add the person in stack*/
				break;
		case 2:
				deleteNode();/*function call to deleteNode function to pop the top most value from the stack*/
				print_stack(top);
				break;
		case 3:
				sort(&top,'d'); /*function call to sort function which will perform merge sort and 'd' means*/
								/*here we are going to perform alphabatic sort*/
				print_stack(top);/*function call to print_stack to print the stack after sorting */
				break;
		case 4:
				sort(&top,'a');	/*function call to sort function but this time with symbol 'a' which means*/
								/*we are going to sort in increasing age value */
				print_stack(top);/*calling print_stack function to print the stack after sorting */
				break;
		case 5:
				printf("exiting...\n");/*if user choose 5 then we exit from the program */
				break;
		default:
				printf("invalid choice!!!\n");
				break;
		}
	}
}
void menu() /*function declaration of menu function.this function just prints the options that this program can do */
{
	printf("\t****MENU****\n");
	printf("1- Add a Person to the Stack\n");
	printf("2- Pop a Person from the Stack\n");
	printf("3- Sort Alphabetical Order\n");
	printf("4- Sort Age in\n");
	printf("5- Exit\n");
}
/*function declaration to addnode. this function takes 4 argument and include them in the stack*/
void addNode(char name[25], char surname [25], char creation [25], int age)
{

	struct person *temp;/*we declare a temp structure pointer*/

	if (top==NULL)/*if our head node is null*/
	{
		temp=(struct person *)malloc(sizeof (struct person));/*we expand the temp structure */
		strcpy(temp->name,name);/*we take the name from user and copy it to name field of  the structure*/
		strcpy(temp->surname,surname);/*we take the surname from user and copy it to surname field of the structure*/
		strcpy(temp->musical_Work,creation);/*we take the creation from user and copy it creation field of the structure*/
		temp->age=age;/*we take the age from user and assign it to age field of the structure*/
		temp->next=NULL;/*we set the pointing pointer of the structure to null*/
		top=temp;/*finally head of the stack is pointing to the created temp structure*/
	}
	else/*but if the head is not empty that means it's already pointing at something then*/
	{
		temp=(struct person *)malloc(sizeof (struct person));/*we expand the temp structure*/
		/*we copy relative fields in the same manner*/
		strcpy(temp->name,name);
		strcpy(temp->surname,surname);
		strcpy(temp->musical_Work,creation);
		temp->age=age;
		temp->next=top;/*the point feild points to what top was pointing at*/
		top=temp;/*then we set top to point at the newly created structure*/
	}
	print_stack(top);/*calling print stack function to print the stack*/
}

/*function declaration to print stack function which will take a node and print it's element*/
void print_stack(struct person *node)
{
	int num=1;/*we set the count value of first element*/
	if(node==NULL)	/*if there is no element in the stack then we print empty stack */
	{
		printf("empty stack!!!\n");
	}
	else	/*but if it's not empty*/
	{
		while(node!=NULL)	/*while the node is not null */
		{
			/*we keep  printing values of the stack */
			printf("\n%d)",num);
			printf("%s\n",node->name );
			printf("%s\n",node->surname );
			printf("%s\n",node->musical_Work );
			printf("%d\n",node->age );
			node=node->next;	/*after printing the first stack elment we increase the pointer position*/
			num++;	/*we also increase the num value to indicate stack element num*/
		}
	}

}
void deleteNode()/*function declaration to deleteNode function.this function pop the top most node from stack*/
{
	/*we declare two temporary structure pointer*/
	struct person *temp;
	struct person *temp1;
	
	if(top!=NULL)/*if the top is not empty then */
	{
		temp=top;/*one temp structure pointer points to head*/
		temp1=top->next;/*the second one points to the next element of the head*/
		temp->next=NULL;/*we cut off the relation between first and second element*/
		free(temp);/*we release the memory for the temp var*/
		top=temp1;/*now the top/head starts to point at the temp1 structure pointer*/
	}
}

/*function declaration to sort function which takes two argument. the first argument takes a pointer to a stack */
/* and the second argument takes what kind of sorting we want to do */
void sort(struct person **top,char x)	
{
	/*we declare two structure pointer and intialize them to null*/
	struct person *a;
	struct person *b;
	a=NULL;
	b=NULL;
	if (*top==NULL ||(*top)->next==NULL)	/*if the stack is empty we simply return */
	{
		return;
	}
	else  /*but if the stack is not empty then*/
	{
		partition(*top,&a,&b);/*we call partition function to divide the stack from the middle*/
		/*this is a recursive call and we keep diving until a single node is reached same like merge sort */
		sort(&a,x);
		sort(&b,x);
		*top=merge(a,b,x);	/* after we reach to a state where no more dividation is possible we merge the two parts according to x value */
		/*the merge function will return the resulted pointer after sorting. so now top pointer will start to point at the result pointer*/
	}
}

/*function declaration to partition function. this function takes three argument. the front and back are pointer to a structure pointer*/
/*actullay here the front means the left side of the stack and back means right side of the stack*/
void partition(struct person *head,struct person **front ,struct person **back)
{
	/*first we declare two pointer. one is slow and one is fast*/
	struct person *slow;
	struct person *fast;
	if (head==NULL || head->next==NULL)/*if the head is null or the pointer part of the head is null then*/
	{
		*front=head;/*we set the front as head */
		*back=NULL;/*and the back as null*/
	}
	else	/*if not so then */
	{
		slow=head;/*firstly we say slow is the head */
		fast=head->next;/*and first is one pointer ahead of the head*/
		while(fast!=NULL)	/*now if fast is not null then we increase fast twice but increase slow by once. so by the time fast reaches the*/
							/*end the slow pointer will reach the middle of the stack*/
		{
			fast=fast->next;
			if(fast!=NULL)
			{
				slow=slow->next;
				fast=fast->next;
			}
		}
		*front=head;/*now the front part starts indicating the head */
		*back=slow->next;/*and back part indicating one step ahead of the middle*/
		slow->next=NULL;/*now we cut off the relation between middle and one step ahead of middle two get two separate node */
	}
}

/*function declaration to merge function which will merge to unsorted node according to value of the argument call 'x' */
/*this function will return a pointer value of the sorted stack*/
struct person *merge(struct person *a,struct person *b,char x)
{
	struct person *result=NULL;/*we declare a temporary structure pointer*/
		if (a==NULL)/*if a is null that means we are only left with b so we return b*/
			return b;
		else if (b==NULL)/*but if b is null then we return a */
			return a;
		if(x=='a')/*then we check the sign of x . if it is a then we sort in increasing age order*/
		{
			if (a->age <= b->age )/*if the age of the left node is less then right node then*/
			{
				result=a;/*result will point at a */
				result->next=merge(a->next,b,x);/*now we increase the position of the result and a then we we go through a recursive process*/
			}
			else/*but if not then vice versa*/
			{
				result=b;
				result->next=merge(a,b->next,x);
			}
		}
		else if(x=='d')/*if the x sign is d then it indicates that we want to sort in alphabatic order*/
		{
			if(strcmp(a->name,b->name)<0)	/*at first we check the name value by putting them in strcmp function and repeats the step like above*/
			{
				result=a;
				result->next=merge(a->next,b,x);
			}
			else if (strcmp(a->name,b->name)>0)
			{
				result=b;
				result->next=merge(a,b->next,x);
			}
			else if(strcmp(a->name,b->name)==0)/*but if the two names are equal then we check the surname . and assign them accordingly*/
			{
				if(strcmp(a->surname,b->surname)<=0)
				{
					result=a;
					result->next=merge(a->next,b,x);
				}
				else if (strcmp(a->surname,b->surname)>=0)
				{
					result=b;
					result->next=merge(a,b->next,x);
				}
			}
		}
		
	return result;	/*finally we return the result pointer*/
}