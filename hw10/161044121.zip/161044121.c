#include <stdio.h> 
#include<stdlib.h> 
#include <time.h>
#define MAX 20  /*defining macro*/

/*defining relaive structures*/
typedef struct stack
{
	int data;
	struct stack *next;
}stack;
typedef struct queue
{
	int data;
	struct queue *next;
}queue;
typedef struct bst
{
	int data;
	struct bst *left;
	struct bst *right;
}bst;

/*function protypes*/
void fill_structures(stack **stack_, queue **queue_, bst **bst_, int data[20]);
void push(stack **stack,int data);
void print(struct stack *stack);
void enqueue(struct queue **queue,int data);
void print_queue(struct queue *queue);
void descending_bst(struct bst *bst) ;
void insert(struct bst **bst,int data);
void ordered_print(stack * stack_, queue * queue_, bst * bst_);
queue *clone_queue(queue *list);
stack *clone_stack(stack *list);
void mergesort_s(struct stack **stack);
void partition_s(struct stack *head,struct stack **front,struct stack **back);
struct stack *merge_s(struct stack *a,struct stack *b);
void mergesort(struct queue **queue);
void partition(struct queue *head,struct queue **front,struct queue **back);
struct queue *merge(struct queue *a,struct queue *b);
void order_stack(stack *root);
void order_queue(queue *root);
void search(stack * stack_, queue * queue_, bst * bst_, int val_to_search);
void search_stack(stack *stack,int value);
void search_queue(queue *queue,int value);
void search_bst(bst *root, int value);
void reverse_q(struct queue **queue);
void reverse_s(struct stack **stack);
void merge_stack_traverse(stack *a,stack *b);
void merge_queue_traverse(queue *a,queue *b);
void queue_traverse(queue *root);
void stack_traverse(stack *root);
void special_traverse(stack * stack_, queue * queue_, bst * bst_);

int main()
{
	int data[20]={5, 2, 7, 8, 11, 3, 21, 7, 6, 15, 19, 35, 24, 1, 8, 12, 17,8, 23, 4};

	bst * bst_;

	queue * queue_;

	stack * stack_;

	stack_=NULL;
	queue_=NULL;
	bst_=NULL;

	fill_structures(&stack_, &queue_, &bst_, data);

	ordered_print(stack_, queue_, bst_);

	search(stack_, queue_, bst_, 5);

	special_traverse(stack_, queue_, bst_);
	
	return 0;
}

/*this function will fill the structures with related values */
void fill_structures(stack **stack_, queue **queue_, bst **bst_, int data[20])
{
	int i;
	double stack_exec,queue_exec,bst_exec;
	clock_t start,end;
	start=clock();/*set timer for execution of filling stack function*/
	for (i=0 ; i < MAX ; i++)/*we run a loop till the end of the given array*/
	{
		push(stack_,data[i]); /*calling push function to start filling the stack*/
	}
	end=clock();/*we mark the end*/
	stack_exec=((double)(end - start))/CLOCKS_PER_SEC;/*we subtrack and get the time in terms of sec*/
	stack_exec*=1000;/*then multiply it by 1000 to get the time in milisec*/
	
	/*for the next two case it's the same logic*/
	start=clock();
	for (i=0 ; i < MAX ; i++)
	{	
		enqueue(queue_,data[i]);
	}
	end=clock();
	queue_exec=((double)(end - start))/CLOCKS_PER_SEC;
	queue_exec*=1000;
		
	start=clock();
	for (i=0 ; i < MAX ; i++)
	{
		
		insert(bst_,data[i]);
	}
	end=clock();
	bst_exec=((double)(end - start))/CLOCKS_PER_SEC;
	bst_exec*=1000;

	printf("structure\t\tstack\t\tqueue\t\tbst\n");
	printf("exec time\t\t%f\t%f\t%f\n",stack_exec,queue_exec,bst_exec);
}

/*declaring function search to find elements in the data structures*/
void search(stack * stack_, queue * queue_, bst * bst_, int val_to_search)
{
	clock_t start,end;
	double stack_exec,queue_exec,bst_exec;
	
	printf("\n");
	start=clock(); 
	search_stack(stack_,val_to_search);/*calling search stack func to search in stack*/
	end=clock();
	stack_exec=((double)(end - start))/CLOCKS_PER_SEC;
	stack_exec*=1000;
	printf("exec time search stack:%f\n\n",stack_exec);
	
	start=clock();	
	search_queue(queue_,val_to_search); /*calling search queue function to search in queue*/
	end=clock();
	queue_exec=((double)(end - start))/CLOCKS_PER_SEC;
	queue_exec*=1000;
	printf("exec time search queue:%f\n\n",queue_exec);

	start=clock();
	search_bst(bst_,val_to_search); /*calling search bst function to search in bst*/
	end=clock();
	bst_exec=((double)(end - start))/CLOCKS_PER_SEC;
	bst_exec*=1000;
	printf("exec time search bst:%f\n\n",bst_exec);
}

/*declaring oredered print function. this func will print the data structures in descending order*/
void ordered_print(stack * stack_, queue * queue_, bst * bst_)
{
	clock_t start,end;
	double stack_exec,queue_exec,bst_exec;
	
	printf("\ndescending stack: ");
	start=clock();
	order_stack(stack_);  /*calling order_stack function to print the stack in descending order*/
	end=clock();
	stack_exec=((double)(end - start))/CLOCKS_PER_SEC;
	stack_exec*=1000;
	printf("\nexec time:%f\n",stack_exec);
	
	printf("\ndescending queue: ");
	start=clock();
	order_queue(queue_);/*calling order_quee function to print the queue in descending order*/
	end=clock();
	queue_exec=((double)(end - start))/CLOCKS_PER_SEC;
	queue_exec*=1000;
	printf("\nexec time:%f\n",queue_exec);
	printf("\ndescending bst  : ");
	start=clock();
	descending_bst(bst_);/*calling descending bst function to print the bst in descending order*/
	end=clock();
	bst_exec=((double)(end - start))/CLOCKS_PER_SEC;
	bst_exec*=1000;
	printf("\nexec time:%f\n",bst_exec);
}
void push(stack **stack,int data)/*function declaration. this function will enter element in the stack*/
{
	/*we declare a temporary structure pointer and mallocate it*/
	struct stack * temp;
    temp =(struct stack *)malloc(sizeof(stack));
    temp->data = data; /*we set the data part with the data needs to be inserted*/
    if(*stack==NULL)	/*at first we check if the stack is empty*/
    {
    	temp->next=NULL;	/*if empty then we set the link part to null*/
    	*stack = temp;	/*then we adjust the head pointer*/
    }
    else/*but if the stack is not empty*/
    {
    	temp->next=*stack;	/*at first the newly created memory will point to where head is pointing*/
    	*stack=temp;	/*then the head will start to point at the new pointer*/
    }
}
void print(struct stack *stack)/*function declaration to print the elements in the stack*/
{
	struct stack *temp;
	temp=stack;	/*the temporary pointer points at the head*/
	if (temp==NULL)/*if the stack has no element*/
	{
		printf("\nempty stack!!!\n");
	}
	else /*but if it has element then loop goes till the stack reaches null and prints it's element*/
	{
		while(temp!=NULL)
		{
			printf("%d ",temp->data );
			temp=temp->next;
		}
	}
}
void enqueue(struct queue **queue,int data)/*function to insert element in the queue*/
{
	struct queue *temp;
	if(*queue==NULL)/*at first if the queue is null */
	{
		temp =(struct queue *)malloc(sizeof(queue));/*we mallocate the memory*/
		temp->data=data;/*fill the data */
		temp->next=NULL;/*set the link part to null*/
		*queue=temp;/*head points to the newly created memory*/
	}
	else/*but if the queue is not null*/
	{
		temp =(struct queue *)malloc(sizeof(struct queue));/*we mallocate the temporary struc pointer*/
	    temp->data = data;/*set the data part to the data need to be inserted*/
	    temp->next=*queue;/*the newly created pointer will point where head is already pointing*/
	    *queue=temp;/*now the head will point at the newly created node*/
	}  
}
void print_queue(struct queue *queue)/*this function prints the elements of the queue using the same logic like stack*/
{
	struct queue *temp;
	temp=queue;
	if (temp==NULL)
	{
		printf("\nempty queue!!!\n");
	}
	else
	{
		while(temp!=NULL)
		{
			printf("%d ",temp->data );
			temp=temp->next;
		}
	}
}
void insert(struct bst **bst,int data)/*this fucntion inserts element at the binary search tree*/
{
	struct bst *temp;
	struct bst *parent;
	struct bst *current;
	temp=(struct bst*)malloc(sizeof(bst));/*we create a new node*/
	temp->data=data;/*fill the data*/
	temp->left=NULL;/*initial left link is null*/
	temp->right=NULL;/*initial right link is null*/
	if(*bst==NULL)/*initially if the bst is empty then head will point at the newly created node*/
	{
		*bst=temp;
	}
	else /*but if the bst is not empty then*/
	{
		current=*bst;	/*current pointer points at the head of the bst*/
		while(current!=NULL) /*now current pointer will run till it reaches end of bst*/
		{
			parent=current;	/*parent pointer will keep track of the current pointer*/
			if(data <= current->data) /*if the data needs to be inserted is less than or equal current node data*/
			{
				current=current->left;/*then we go to the left side of the tree*/
			}
			else /*otherwise we go to the right side of the tree */
			{
				current=current->right;
			}
		}
		/*now we got the parent node */
		if(data <= parent->data)/*again we check if the data is less than or equal to the parent node data*/
		{
			parent->left=temp; /*condition true then new node belong to the left side*/
		}
		else /*otherwise it will go to the right side of the parent node*/
		{
			parent->right=temp;
		}
	}
}
void descending_bst(struct bst *root) /*this function will print the bst in descending order recursively*/
{ 
	if (root!= NULL) /*base condition*/
	{ 
		descending_bst(root->right); /*at first we go to the right side because right side contains the higher values*/
		printf("%d ", root->data); /*we print the datas*/
		descending_bst(root->left); /*we come to the left side*/
	} 
} 

/*this function will create a exact looking queue */
queue *clone_queue(queue *list) 
{
    if (list == NULL) /*if the queue we are looking to clone is null then we return null,base case*/
    	return NULL;
    else 
    {
    	/*otherwise we create  new node and set the link part exactly like the given queue*/
    	queue* result = (struct queue *)malloc(sizeof(queue));
	    result->data = list->data;
	    result->next = clone_queue(list->next);/*recursive part*/
	    return result;/*we return the head pointer*/
    }  
}
/*this function clones a given stack in the same way it does for queue*/
stack *clone_stack(stack *list) 
{
    if (list == NULL) 
    	return NULL;
    else
    {
    	stack* result = (struct stack *)malloc(sizeof(stack));
	    result->data = list->data;
	    result->next = clone_stack(list->next);
	    return result;
    }  
}
/*this function prints the stack in the descending order without changing the main stack*/
void order_stack(stack *root)
{
	struct stack *stack;
	stack=clone_stack(root);/*calling clone stack function */
	mergesort_s(&stack);/*calling merge sort function to sort the cloned stack*/
	print(stack);/*print the stack in descending order*/
}
/*this function prints the queue in descending order in the same way like stack*/
void order_queue(queue *root)
{
	struct queue *queue;
	queue=clone_queue(root);
	mergesort(&queue);
	print_queue(queue);
}

/*function declaration of search stack function*/
void search_stack(stack *stack,int value)
{
	struct stack *temp;
	int flag=0 ,step=0;
	temp=stack;/*at first the temporary pointer points at the head*/
	if(temp==NULL)/*if the stack is empty then there is nothing to search*/
	{
		printf("empty stack\n");
		return;
	}
	while(temp!=NULL)/*otherwise we run a loop till the end */
	{
		if(temp->data==value)/*if we find the data then we increase the flag value*/
		{
			flag++;
		}
		else/*otherwise we continue */
		{
			step++;
		}
		temp=temp->next;
	}
	if(flag!=0)/*if the flag value is not zero that means we found the element */
	{
		printf("%d result founded on %d step\n",flag,step);
	}
	else if(flag==0)
	{
		printf("data not found\n");
	}
}

/*this function search the queue using the same logic like queue*/
void search_queue(queue *queue,int value)
{
	struct queue *temp;
	struct queue *temp1;
	int flag=0 ,step=0;
	temp=queue;
	if(temp==NULL)
	{
		printf("empty queue\n");
		return;
	}
	while(temp!=NULL)
	{
		if(temp->data==value)
		{
			flag++;
		}
		else
		{
			step++;
		}
		temp=temp->next;
	}
	if(flag!=0)
	{
		printf("%d result founded on %d step\n",flag,step);
	}
}

/*this function is to serch the data in the bst*/
void search_bst(bst *root, int value)
{
	int flag=0,step=0;
	bst *current = root;/*initially current node points at the head*/
	bst *parent = NULL;/*initially the parent node is null*/
	while (current != NULL)/*now current loop will go till it reach a end*/
	{
		parent = current;/*we keep track of the current node*/
		if(parent->data==value)/*if the value is found then we increase the flag value*/
		{
			flag++;
		}
		if (value <= current->data)/*if data needs to be found is less than current node data then we go left*/
		{
			step++;
			current = current->left;
		}
		else /*otherwise we go the right side*/
		{
			step++;
			current = current->right;
		}
	}
	if(flag!=0)/*if data is found*/
	{
		printf("%d result founded on %d step\n",flag,step);
	}
	else if(flag==0)
	{
		printf("data not found\n");
	}
}
/*function declaration to sort function */
void mergesort_s(struct stack **stack)
{
	/*we declare two structure pointer and intialize them to null*/
	struct stack *a;
	struct stack *b;
	a=NULL;
	b=NULL;
	if (*stack==NULL || (*stack)->next==NULL)/*if the stack is empty we simply return */
	{
		return;
	}
	else/*but if the stack is not empty then*/
	{
		partition_s(*stack,&a,&b);/*we call partition function to divide the stack from the middle*/
								/*this is a recursive call and we keep diving until a single node is reached same like merge sort */
		mergesort_s(&a);
		mergesort_s(&b);
		*stack=merge_s(a,b);/* after we reach to a state where no more dividation is possible we merge the two parts */
/*the merge function will return the resulted pointer after sorting. so now top pointer will start to point at the result pointer*/
	}

}

/*function declaration to partition function. this function takes three argument. the front and back are pointer to a structure pointer*/
/*actullay here the front means the left side of the stack and back means right side of the stack*/
void partition_s(struct stack *head,struct stack **front,struct stack **back)
{
	/*first we declare two pointer. one is slow and one is fast*/
	struct stack *slow;
	struct stack *fast;
	if (head==NULL ||head->next==NULL)/*if the head is null or the pointer part of the head is null then*/
	{
		*front=head;/*we set the front as head */
		*back=NULL;/*and the back as null*/
	}
	else/*if not so then */
	{
		slow=head;/*firstly we say slow is the head */
		fast=head->next;/*and first is one pointer ahead of the head*/
		while (fast!=NULL)/*now if fast is not null then we increase fast twice but increase slow by once. so by the time fast reaches the*/
		{					/*end the slow pointer will reach the middle of the stack*/
			fast=fast->next;
			if (fast!=NULL)
			{
				slow=slow->next;
				fast=fast->next;
			}
		}
		*front=head;/*now the front part starts indicating the head */
		*back=slow->next;/*and back part indicating one step ahead of the middle*/
		slow->next=NULL;/*now we cut off the relation between middle and one step ahead of middle two get two separate node */
	}
}
/*function declaration to merge function which will merge to unsorted ll */
/*this function will return a pointer value of the sorted stack*/
struct stack *merge_s(struct stack *a,struct stack *b)
{
	struct stack *result=NULL;
	if (a==NULL)/*if one side is null we return the other side*/
		return b;
	else if (b==NULL)
		return a;
	
	if (a->data >= b->data) /*if the data is of left stack is greater than the right stack*/
	{
		result=a;/*the result will point at the left stack*/
		result->next=merge_s(a->next,b);/*we are calling the function recursively by increamentin relative values*/
	}
	else/*vice versa */
	{
		result=b;
		result->next=merge_s(a,b->next);
	}
	return result;/*we return the head to the new stack*/
}

void mergesort(struct queue **queue)/*this function use the same logic but for queue*/
{
	struct queue *a;
	struct queue *b;
	a=NULL;
	b=NULL;
	if (*queue==NULL || (*queue)->next==NULL)
	{
		return;
	}
	else
	{
		partition(*queue,&a,&b);
		mergesort(&a);
		mergesort(&b);
		*queue=merge(a,b);
	}

}
/*this function does the same of partitioning but for queue*/
void partition(struct queue *head,struct queue **front,struct queue **back)
{
	struct queue *slow;
	struct queue *fast;
	if (head==NULL ||head->next==NULL)
	{
		*front=head;
		*back=NULL;
	}
	else
	{
		slow=head;
		fast=head->next;
		while (fast!=NULL)
		{
			fast=fast->next;
			if (fast!=NULL)
			{
				slow=slow->next;
				fast=fast->next;
			}
		}
		*front=head;
		*back=slow->next;
		slow->next=NULL;
	}
}

/*function merge two sorted queue using the same logic like stack merging*/
struct queue *merge(struct queue *a,struct queue *b)
{
	struct queue *result=NULL;
	if (a==NULL)
		return b;
	else if (b==NULL)
		return a;
	
	if (a->data >= b->data)
	{
		result=a;
		result->next=merge(a->next,b);
	}
	else
	{
		result=b;
		result->next=merge(a,b->next);
	}
	return result;
}
/*this function reverse  a queue*/
void reverse_q(struct queue **queue)
{
	/*we declare three pointer to keep track of current prev and next position*/
	struct queue *prev=NULL;
	struct queue *current;
	struct queue *next;
	current=*queue;/*initially current points at the head of the queue*/
	while(current!=NULL)/*now runs a loops till the end of the queue*/
	{
		next=current->next;/*we store the next pointer adress*/
		current->next=prev;/*the link part of the current pointer is the adrress of the previous node*/
		prev=current;/*now we update the previous to current */
		current=next;/*and current will be the next pointer*/
	}
	*queue=prev;/*the new head*/
}

/*this function reverse a stack using the same logic like reversing a queue*/
void reverse_s(struct stack **stack)
{
	struct stack *prev=NULL;
	struct stack *current;
	struct stack *next;
	current=*stack;
	while(current!=NULL)
	{
		next=current->next;
		current->next=prev;
		prev=current;
		current=next;
	}
	*stack=prev;
}

/*this function prints the stack in max and min form by merging two stack together*/
void merge_stack_traverse(stack *a,stack *b)
{
	struct stack *result=NULL;
	struct stack *temp;
	/*at this point the right of the stack is in descending order*/
	reverse_s(&b);/*we make it ascending by reversing the stack using reverse_s function*/
	printf("\nspecial traverse stack: ");
	while(a)/*the length of a is always greater or equal to b. so we run a loop till a is satisfied*/
	{
		printf("%d %d ",a->data,b->data);/*we print one value from left and then one from right */
		a=a->next;/*update the left pointer */
		b=b->next;/*update the right pointer*/
	}
	printf("\n");
}
/*this function does the same job of merging and printing but for queue using the same logic of stack*/
void merge_queue_traverse(queue *a,queue *b)
{
	struct queue *result=NULL;
	struct queue *temp;
	reverse_q(&b);
	printf("\nspecial traverse queue: ");
	while(a)
	{
		printf("%d %d ",a->data,b->data);
		a=a->next;
		b=b->next;
	}
	printf("\n");
}

/*this function will accumulate the traverse printing process for stack*/
void stack_traverse(stack *root)
{
	struct stack *stack;
	stack=clone_stack(root);/*at first we make a clone of the original stack*/
	mergesort_s(&stack);/*we mergesort the stack in descending order*/
	struct stack *temp;
	struct stack *temp1;
	partition_s(stack,&temp,&temp1);/*we does the partition of the stack*/
	merge_stack_traverse(temp,temp1);/*we print the value in max min order*/
}

/*this fucntion accumulate the travese printing process for queue*/
void queue_traverse(queue *root)
{
	struct queue *queue;
	queue=clone_queue(root);
	mergesort(&queue);
	struct queue *temp;
	struct queue *temp1;
	partition(queue,&temp,&temp1);
	merge_queue_traverse(temp,temp1);
}

/*function declaration to special travese to print the data structure in max min for*/
void special_traverse(stack * stack_, queue * queue_, bst * bst_)
{
	clock_t start,end;
	double stack_exec,queue_exec,bst_exec;

	start=clock();
	stack_traverse(stack_);/*calling stack traver function */
	end=clock();
	stack_exec=((double)(end - start))/CLOCKS_PER_SEC;
	stack_exec*=1000;
	printf("exec time stack:%f\n\n",stack_exec);

	start=clock();
	queue_traverse(queue_);/*calling queue traverse function*/
	end=clock();
	queue_exec=((double)(end - start))/CLOCKS_PER_SEC;
	queue_exec*=1000;
	printf("exec time queue:%f\n\n",queue_exec);
}